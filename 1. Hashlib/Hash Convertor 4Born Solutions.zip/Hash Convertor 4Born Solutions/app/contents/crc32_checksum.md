---
title: CRC-32 File Checksum
template: page.pug
js: https://cdn.jsdelivr.net/gh/emn178/js-crc/build/crc.min.js
method: crc32
action: Hash
auto_update: true
file_input: true
description: CRC-32 online file checksum function
keywords: CRC,CRC-32,online,checksum
---
