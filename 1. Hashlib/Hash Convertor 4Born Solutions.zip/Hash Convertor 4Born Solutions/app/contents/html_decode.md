---
title: HTML Decode
template: page.pug
js: https://cdn.jsdelivr.net/gh/emn178/js-htmlencode/build/htmlencode.min.js
method: htmlDecode
action: Decode
auto_update: true
description: HTML online decode function
keywords: HTML,online,decode
---
